import express from "express";
import { Request, Response } from "express";
import { PrismaClient } from "../../generated/prisma-client";

const prisma = new PrismaClient();

const servicesRoute = express.Router();

servicesRoute.get("/services", async (req: Request, res: Response) => {
  const services = await prisma.services.findMany();
  res.json(services);
});

export default servicesRoute;