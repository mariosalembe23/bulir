export interface loginData {
  name: string;
  email: string;
}
